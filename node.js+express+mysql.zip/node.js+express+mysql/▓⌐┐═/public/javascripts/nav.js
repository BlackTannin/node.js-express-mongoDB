$(function () {
    $.ajax({
        method:'GET',
        url:'http://localhost:3000/getnav',
        dataType:'JSON'
    }).then(result=>{
        result.forEach((category,i)=>{
            $('#navlinks').append('<li class="nav-item dropdown">' +
                '<a class="nav-link dropdown-toggle" href="#" cid="'+category.id+'" id="navbarDropdown'+category.id+'" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' +category.name+'</a>' +
                '<div class="dropdown-menu" aria-labelledby="navbarDropdown'+$(this).attr('cid')+'"></div>'+
                '</li>');
        })
    });

    $('#navlinks').on('click','li>a',function () {
        $.ajax({
            method:'GET',
            url:'http://localhost:3000/getsub/'+$(this).attr('cid'),
            dataType:'JSON'
        }).then(result=>{
            console.log(result)
            if(result.length>0){
                var str = '';
                result.forEach(function(sub,i){
                    str += '<a class="dropdown-item" href="#">'+sub.name+'</a><div class="dropdown-divider"></div>';
                });
                $(this).next("div").append(str);
            }else{
                $(this).next("div").append('<a class="dropdown-item" href="#">暂无分类</a>');
            }
        })
    })
})
