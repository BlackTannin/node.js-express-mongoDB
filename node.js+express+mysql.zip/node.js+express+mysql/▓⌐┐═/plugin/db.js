//第一步 引入mysql
var mysql = require("node-mysql-promise");

//第二步 设置数据库连接配置
var db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'bailiban',
    port:'3306'
});


module.exports = db;
