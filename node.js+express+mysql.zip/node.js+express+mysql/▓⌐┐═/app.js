var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');



var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var webRouter = require('./routes/website');
var adminIndex = require('./routes/admin/index');

var logger = require('morgan');
var session = require('express-session');
var flash = require('connect-flash');
//包含cors包
var cors = require("cors");
var app = express();
//设置跨域
app.use(cors({
  "origin": "*",
  "methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
  "preflightContinue": false,
  "optionsSuccessStatus": 200
}));
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: {maxAge:3600000}
}));
// view engine setup
app.set('views', path.join(__dirname, 'views'));
//加载ejs模板引擎
app.engine('html',require('ejs').__express);
app.set('view engine', 'html');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

//使用flash插件
app.use(flash());
//app.locals>res.locals
//全局有效
app.locals.siteinfo={
  title:'百里半官方网站',
  keywords:"IT培训,前端培训,百里半,百里半教育",
  description:'百里半教育是一家综合互联网教育机构'
}

//路由下有效， 路由守卫模式
app.use(function (req,res,next) {
  res.locals.message = req.flash("message").toString();
  res.locals.type = req.flash('type').toString();
  res.locals.isLogin = req.session.isLogin;
  next();
});
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/web', webRouter);

//模块的路由守卫
app.use(function(req, res,next) {
  if(!req.session.user){
    res.redirect("back")
  }else{
    if(!req.session.user.isadmin){
      res.redirect("back")
    }else{
      next();
    }
  }
});
app.use('/admin',adminIndex);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});


module.exports = app;
