var express = require("express");
var router = express.Router();

router.get("/",function (req,res) {

    res.render("website",{name:"百里半网站",title:"北京百里半",beian:"京ICP备9876-2"});
});


module.exports = router;
