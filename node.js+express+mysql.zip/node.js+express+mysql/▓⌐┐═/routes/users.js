var express = require('express');
var multer = require("multer");
var router = express.Router();
var db = require('../plugin/db');
var path = require('path');
var fs = require('fs');
var upload = multer(
    {
                dest: 'public/uploads/headpic',
                limits:{
                        filesize:1024*1024*1024*5
                }
    });



/* GET users listing. /users */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//  /users/list
router.get('/list', function(req, res, next) {
  res.send('respond with a resource');
});

//用户登录界面
router.get("/login",function (req,res) {
  res.render("user/login",{title:"用户登录页面"});
});

//接受登录数据并验证 /users/login
router.post("/login",function (req,res) {
  var username = req.body.username;
  var userpwd = req.body.userpwd;
  //and 查询
  db.table("users").where({username:username,userpwd:userpwd}).find()
      .then(result=>{

        if(result.username){
          req.flash("type","success");
          req.flash("message","登录成功");

          req.session.isLogin = true;
          req.session.user=result;
          res.redirect("/")
        }else{
            req.flash("type","warning");
            req.flash("message","用户名或密码错误，请重新登录");
           /* req.session.type="warning";
            req.session.message = "用户名或密码错误，请重新登录";*/
            req.session.isLogin = false;

          res.redirect("back");
        }
      })



});

//用户注册界面 /users/register
router.get("/register",function (req,res) {
  res.render("user/register",{title:"用户注册页面"});
});

router.post("/register",function (req,res) {

  //1,获取form表单数据
  var username = req.body.username;
  var email = req.body.email;
  var userpwd = req.body.userpwd;
  var reuserpwd = req.body.reuserpwd;

  if(userpwd != reuserpwd){
    //跳转回去
    res.redirect("back");


  }else{
      db.table("users").thenAdd({username:username,email:email,userpwd:userpwd},{username:username,email:email,_logic:"OR"},true)
          .then(data=>{

            if(data.type=='exist'){
                req.flash("type","warning");
                req.flash("message","用户名或邮箱已被占用，请重新填写");
                /*req.session.type="warning";
                req.session.message = "用户名或邮箱已被占用，请重新填写";*/
                req.session.isLogin = false;
              res.redirect("back");
            }
            if(!data){
                req.flash("type","warning");
                req.flash("message","用户注册失败");
               /* req.session.type="warning";
                req.session.message = "用户注册失败";*/
                req.session.isLogin = false;
              res.redirect("back");
            }
            return data;
          }).then(result=>{

          req.flash("type","success");
          req.flash("message","注册成功，您已成功登录");
         /* req.session.type="success";
          req.session.message = "注册成功，您已成功登录";*/
          req.session.isLogin = true;
            req.session.user={
                username:username,
                email:email
            };
            res.redirect("/")
      })
  }

});

//显示用户信息页面
router.get("/info",function(req,res,next){
    if(req.session.isLogin){
        next()
    }else{
        res.redirect("/users/login")
    }

},function (req,res) {

    res.render("user/info",{title:"用户信息页面",user:req.session.user});
});

router.post("/info",function(req,res,next){
    if(req.session.isLogin){
        next()
    }else{
        res.redirect("/users/login")
    }

},upload.single('headpic'),function (req,res) {

        var email = req.body.email;
        var userpwd = req.body.userpwd;
        var reuserpwd =req.body.reuserpwd;
        var contents = req.body.contents;
        var data = {};
        data.email = email;
        data.contents = contents;
        if(userpwd && userpwd == reuserpwd){
            data.userpwd = userpwd;
        }
        if(req.file){

                                        //2.jpg
            var extname = path.extname(req.file.originalname);//得到后缀 .jpg

            //              asdfasdflladfj  + .jpg
            /*var filename = req.file.filename+extname;
            //public/uploads/headpic/asdasdfa + .jpg
            var file = req.file.path+extname;*/

            //202003051581231238778.jpg 根据时间生成文件名和新的路径名称
            var filename = Date.now()+Math.floor(Math.random()*1000)+extname;
            var file = req.file.destination+'/'+filename;
             //改名+覆盖源路径文件
            fs.rename(req.file.path,file,(err)=>{
                if(!err){
                    data.headpic = filename;

                    db.table("users").where({id:req.session.user.id}).update(data).then(affectRows=>{
                        if(affectRows>0){
                            req.session.user.headpic=filename;
                            req.session.user.email=email;
                            req.session.user.contents=contents;
                            req.flash("type","success");
                            req.flash("message","用户信息修改成功");
                            res.redirect("/users/info")
                        }else{
                            req.flash("type","danger");
                            req.flash("message","修改信息失败");
                            res.redirect("back")
                        }

                    });
                }
            });
        }else{

            /*
            * {
            * email:'xiaobao@qq.com',
            * password:'123456',
            * headpic:'aldfaldfasdfas.jpg',
            * contents:'aasdfsadfasdfa'
            * }
            *
            * */
            db.table("users").where({id:req.session.user.id}).update(data).then(affectRows=>{
                if(affectRows>0){
                    req.session.user.email=email;
                    req.session.user.contents=contents;
                    req.flash("type","success");
                    req.flash("message","用户信息修改成功");
                    res.redirect("/users/info")
                }else{
                    req.flash("type","danger");
                    req.flash("message","修改信息失败");
                    res.redirect("back")
                }

            });
        }

    //成功就给出成功信息，返回到用户信息页面

    //失败，告知错误信息，返回上一个页面
});

router.post("/uploads",upload.single('editormd-image-file'),function (req,res) {
    if(req.file) {

        //2.jpg
        var extname = path.extname(req.file.originalname);//得到后缀 .jpg


        //202003051581231238778.jpg 根据时间生成文件名和新的路径名称
        var filename = Date.now() + Math.floor(Math.random() * 1000) + extname;
        var file = req.file.destination + '/' + filename;
        //改名+覆盖源路径文件
        fs.rename(req.file.path, file, (err) => {
            if (!err) {
                res.json({
                    success : 1,           // 0 表示上传失败，1 表示上传成功
                    message : "提示的信息，上传成功",
                    url     : "/uploads/headpic/"+filename        // 上传成功时才返回
                })
            }else{
                res.json({
                    success :0 ,           // 0 表示上传失败，1 表示上传成功
                    message : "提示的信息，上传失败",
                    url     : ''        // 上传成功时才返回
                })
            }
        })
    }
});
//
router.get("/myarticle",function(req,res,next){
    if(req.session.isLogin){
        next()
    }else{
        res.redirect("/users/login")
    }

},function (req,res,next) {
    db.table("article").where({author:req.session.user.id}).select()
        .then(result=>{
            console.log(result)
            if(result.length>0){
                res.render("user/myarticle",{title:"文章列表",data:result})
            }else{
                res.render("user/myarticle",{title:"文章列表"})
            }
        })

})
//修改文章
router.get("/edit/:id",function(req,res,next){
    if(req.session.isLogin){
        next()
    }else{
        res.redirect("/users/login")
    }

},async function(req,res){
    var subcat={};
    await db.table('subcate').order('orderno').select()
        .then(sub=>{
            subcat=sub;
        })
    await db.table("article").where({id:req.params.id}).find()
        .then(result=>{

            if(result){
                res.render("user/edit",{title:"文章编辑页面",subcat:subcat,data:result})
            }else{
                req.flash('type','warning');
                req.flash('message','没有查询到文章内容');
                res.redirect("back")
            }
        })

});

router.post("/edit/:id",function(req,res,next){
    if(req.session.isLogin){
        next()
    }else{
        res.redirect("/users/login")
    }

},function(req,res){
    var id = req.params.id;
    var title = req.body.title;
    var contents = req.body['contents-html-code'];
    var mdcontents = req.body['contents-markdown-doc'];
    var sid = req.body.sid;
    var update_at = Date.now();

    db.table("article").where({id:id}).update({title:title,contents:contents,mdcontents:mdcontents,sid:sid,update_at:update_at})
        .then(result=>{
            if(result){
                req.flash('type','success');
                req.flash("message","更新文章成功");
                res.redirect('/users/myarticle');
            }else{
                req.flash('type','warning');
                req.flash("message","更新文章失败");
                res.redirect('back');
            }
        })
});

router.get("/delete/:id",function(req,res,next){
    if(req.session.isLogin){
        next()
    }else{
        res.redirect("/users/login")
    }

},function(req,res){
    db.table('article').where({id:req.params.id}).delete()
        .then(result=>{
            if(result){
                req.flash('type','success');
                req.flash("message","删除文章成功");
                res.redirect('/users/myarticle');
            }else{
                req.flash('type','danger');
                req.flash("message","删除文章失败");
                res.redirect('back');
            }
        })
})


router.get("/logout",function (req,res) {
    //判断，如果是已经登录了。跳转到个人信息页或者是首页
    req.session.destroy(function (err) {
        if(!err){
            res.redirect("/");
        }
    })
});
//common.js的语法规范
module.exports = router;
