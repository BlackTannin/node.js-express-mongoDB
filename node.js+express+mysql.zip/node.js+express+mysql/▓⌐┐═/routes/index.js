var express = require('express');
var router = express.Router();
//时间处理包，包含进来
var moment = require('moment');
//1,npm install --save node-mysql-promise
//2,引入
var db = require("../plugin/db");
var makdown = require("markdown").markdown;

/* GET home page. */
router.get('/', async function(req, res) {
  //4,数据操作
  await db.table("users").select().then(result=>{
    user = result;
  });
  res.render('index', { title: 'Express',users:user,loginUser:req.session.user});
});

//获取一级分类数据
router.get('/getnav',function(req, res) {
  db.table("category").order('orderno').select()
      .then(result=>{
        res.json(result);
  })
});

//获取二级子菜单
router.get('/getsub/:id', async function(req, res) {
  await db.table('subcate').where({pid:req.params.id}).select().then(result=>{
    //给ajax提供数据
    res.json(result);
  })
});
router.post('/addcategory', function(req, res) {
  var name = req.body.name;
  var orderno = req.body.orderno;

  db.table("category").add({name:name,orderno:orderno}).then(result=>{
    res.json(result);
  })
});

async function getNav(){
  var categories=[];
  await db.table("category").order('orderno').select().then(result=>{
    categories=result;
  });
  categories.forEach(async function(category,i) {
    await db.table("subcate").where({pid: category.id}).select().then(result => {
      if (result.length > 0) {
        categories.subcate = result;
      }
    });
  });
   return categories
}

//获取文章列表
router.get("/list/:id",function (req,res) {
  db.table("article").where({sid: req.params.id}).page(1,10).countSelect().then(result => {

     result.data.forEach(function(v,i){
          //格式化时间戳为：2020-03-09 12:00:43格式
          result.data[i].create_at =moment(result.data[i].create_at).format('YYYY-MM-DD HH:MM:SS');
      })

    res.render("list", {title:'文章列表',data: result});
  })
})

//API获取文章列表
router.get("/apilist/:id",async function (req,res) {
    console.log(req.params);
   await db.table("article").where({sid: req.params.id}).select().then(result => {
        result.forEach(function(v,i){
            //格式化时间戳为：2020-03-09 12:00:43格式
            result[i].create_at =moment(result[i].create_at).format('YYYY-MM-DD HH:MM:SS');
        })
       res.json(result);
    })

})
/*添加文章*/
router.get("/addarticle",function(req,res,next){
  if(req.session.isLogin){
    next()
  }else{
    res.redirect("/users/login")
  }

},function (req,res) {
  db.table("subcate").order('orderno').select()
      .then(result=>{
        if(result.length>0){
          res.render('addarticle',{title:'添加文章页面',data:result})
        }
      })

})
router.post("/addarticle",function(req,res,next){
  if(req.session.isLogin){
    next()
  }else{
    res.redirect("/users/login")
  }

},function (req,res) {
    console.log(req.body);
    var title = req.body.title;
    var contents = req.body['contents-html-code'];
    var mdcontents = req.body['contents-markdown-doc'];
    var sid = req.body.sid;
    var author = req.session.user.id;
    var create_at = Date.now();
    var update_at = Date.now();
    db.table('article').add({title:title,sid:sid,contents:contents,mdcontents:mdcontents,author:author,create_at:create_at,update_at:update_at})
        .then(function (result) {
          req.flash("type","success");
          req.flash("message","发布文章成功");
          res.redirect("/")
        }).catch(err=>{
          req.flash("type","danger");
          req.flash("message","发布文章失败");
          res.redirect("back")
    })

})

//文章的详情页面
router.get("/show/:id",async (req,res)=>{
    await db.table("article").where({id:req.params.id}).find()
        .then(async result=>{
            if(result){
                result.create_at =moment(result.create_at).format('YYYY-MM-DD HH:MM:SS');
                var author = result.author;
                await db.table("users").where({id:author}).find()
                    .then(data=>{
                        if(data){
                        result.author = data.username;
                        }
                    })
                res.type('html');

                res.render("show",{title:'文章详情页',data:result});
            }else{
                req.flash("type","warning");
                req.flash("message","没有查到文章内容");
                res.redirect("back");
            }
        })

})
/*搜索*/
router.get("/search",async function (req,res) {
    var keywords = req.query.keywords;
    var page = req.query.page;
    //1，当前是第几页
    page = Math.abs(page)>0 ? page : 1;         //占一页
    page = page>pagecount ? pagecount :page;
    //2,
    var total = 0;//总数据条数
    await db.table('article').where({title: ['LIKE', `%${keywords}%`]}).count('id')
        .then(count=>{
            total=count;
        });
    var pagesize = 4;//单个页面的数据条数
    //3,总共多少页  count/单页面条数
    var pagecount = Math.ceil(total/pagesize);//总的页数
    //4,偏移量
      var offset = (page-1)*pagesize;
      //0,4  第一页
    //4,4   第二页
    //8,4   第三页
    await db.table("article").where({title: ['LIKE', `%${keywords}%`]}).limit(offset,pagesize).select()
        .then(result=>{
            if(result.length>0){
                console.log(result)
                res.render("search",{title:'搜索结果',data:result,page:page,pagecount:pagecount,keywords:keywords})
            }
        });
})
module.exports = router;
