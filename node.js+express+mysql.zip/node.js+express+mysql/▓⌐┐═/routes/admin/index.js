var express = require('express');
var router = express.Router();
//2,引入
var db = require("../../plugin/db");



/* GET home page. */
router.get('/', async function(req, res) {
  res.render("admin/index")
});
router.get('/navlist',function (req,res) {
  db.table("category").order('orderno').select().then(function (result) {
    if(result.length>0){
      res.render('admin/navlist',{categories:result})
    }
  });

});

router.get('/sublist/:id',function (req,res) {
  db.table("subcate").where({pid:req.params.id}).order('orderno').select().then(function (result) {
    if(result.length>0){
      res.render('admin/sublist',{subcates:result})
    }
  });

});

//文章列表
router.get("/articlelist",function (req,res) {
  var page= req.query.page ? Math.abs(req.query.page) :1;
  db.table("article").page(1,10).countSelect()
      .then(result=>{
        res.render('admin/articlelist',{title:'文章列表',data:result})
      })
})
//用户列表
router.get("/userlist",function (req,res) {
  var page= req.query.page ? Math.abs(req.query.page) :1;
  db.table("users").page(1,10).countSelect()
      .then(result=>{
        res.render('admin/userlist',{title:'用户列表',data:result})
      })
})
module.exports = router;
