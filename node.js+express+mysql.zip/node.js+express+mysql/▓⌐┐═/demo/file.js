var path = require("path");
//当前路径
/*console.log("这是输出的dirname的值",__dirname);
console.log("这是输出的filename的值",__filename);*/

var file = __filename;//D:\前端课程\express_lesson\app01\demo\file.js

/*var bname = path.basename(file);
var bname = path.basename(file,'.js');*/

//D:\前端课程\express_lesson\app01\headpic.jpg
// console.log(bname)

// console.log(path.dirname(file))
console.log(path.extname(file))
console.log(path.parse(file));
