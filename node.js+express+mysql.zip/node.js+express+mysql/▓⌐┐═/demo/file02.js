let fs = require("fs");

/*fs.mkdir("./ABC",{},(err)=>{
    console.log(err);
})*/
/*fs.mkdir("../a/b/c/d/e",{recursive:true },err=>{
    console.log(err)
})*/

/* fs.readdir("../public/uploads/headpic",(err,result)=>{
    console.log(result);
});*/

/*fs.rmdir("../a/b/c/d/e",function (err) {
    console.log(err);
})*/

//改名并移动位置
/*fs.rename("../A","./a",err=>{
    console.log(err)
})*/

fs.stat("./a",function (err,stats) {
    console.log(stats);
    console.log(stats.isFile());
    console.log(stats.isDirectory());
})
